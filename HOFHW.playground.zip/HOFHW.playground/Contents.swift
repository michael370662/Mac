import UIKit

//params for concatenate function
let arrOfString = ["clever", "meek", "hurried", "nice"]

let appendString = "ly"

let arrOfString1 = ["new", "pander", "scoop"]

let appendString1 = "er"

let arrOfString2 = ["bend", "sharpen", "mean"]

let appendString2 = "ing"

// function that append second string to an array of string
func concatenate(_ origString : [String],_ addString : String)-> [String] {
 
    var newString : [String] = []
    for value in origString { newString.append(value + addString) }
    return newString
}
//test cases for the concatenate function
let newString0 = concatenate(arrOfString, appendString)
let newString1 = concatenate(arrOfString1, appendString1)
let newString2 = concatenate(arrOfString2, appendString2)

print (newString0)
print (newString1)
print (newString2)

//params for additiveInverse function
let oldArrOfInt0 = [5, -7, 8, 3]
let oldArrOfInt1 = [1, 1, 1, 1, 1]
let oldArrOfInt2 = [-5, -25, 35]

//AdditiveInverse func aka takes an array of int and return the 2's complements
func additiveInverse(_ arrayOfInt : [Int]) -> [Int]{
    var newArr: [Int] = []
    for value in arrayOfInt { newArr.append(value * -1) }
    return newArr
}
//test cases for additiveInverse
let newSetOfNum0 = additiveInverse(oldArrOfInt0)
let newSetOfNum1 = additiveInverse(oldArrOfInt1)
let newSetOfNum2 = additiveInverse(oldArrOfInt2)
print(newSetOfNum0)
print(newSetOfNum1)
print(newSetOfNum2)


//params for minimumRemovals
let arrayOfInt0 = [1, 2, 3, 4, 5]

let arrayOfInt1 = [5, 7, 9, 11]

let arrayOfInt2 = [5, 7, 9, 12]

// function to find the count of number to be removed for the sum of the provided array to be even
func minimumRemovals(_ arrOfInt : [Int]) -> Int
{
    var count = 0
 
    for value in arrOfInt {
        if (value % 2 == 1) {
            count += 1 /* counts only odd numbers */
        }
    }
    /* if the counter is even return 0
       otherwise return 1 */
    if (count % 2 == 0) {
        return 0
    } else {
        return 1
    }
}

//test cases for minimumRemovals

let minRemovalCounts0 = minimumRemovals(arrayOfInt0)
let minRemovalCounts1 = minimumRemovals(arrayOfInt1)
let minRemovalCounts2 = minimumRemovals(arrayOfInt2)

print (minRemovalCounts0)
print (minRemovalCounts1)
print (minRemovalCounts2)

//params for existsHigher
let arrOfInt0 = [5, 3, 15, 22, 4]
let thershold0 = 10

let arrOfInt1 = [1, 2, 3, 4, 5]
let thershold1 = 8

let arrOfInt2 = [4, 3, 3, 3, 2, 2, 2]
let thershold2 = 4

let arrOfInt3 : [Int] = []
let thershold3 = 5

//function that returns true if there exists a number meeting thershold
func existsHigher(_ arrOfInt : [Int],_ thershold : Int) -> Bool {
    for value in arrOfInt {
        if(value >= thershold) {
            return true
        }
    }
        
    return false
}
//test cases for exitsHigher function
let higherThanThershold0 = existsHigher(arrOfInt0, thershold0)
let higherThanThershold1 = existsHigher(arrOfInt1, thershold1)
let higherThanThershold2 = existsHigher(arrOfInt2, thershold2)
let higherThanThershold3 = existsHigher(arrOfInt3, thershold3)

print(higherThanThershold0)
print(higherThanThershold1)
print(higherThanThershold2)
print(higherThanThershold3)

//params for filterUnique
let stringToBeFiltered0 = ["abb", "abc", "abcdb", "aea", "bbb"]
let stringToBeFiltered1 = ["88", "999", "989", "9988", "9898"]
let stringToBeFiltered2 = ["ABCDE", "DDEB", "BED", "CCA", "BAC"]
//Function filterUnique returns unique string in an array of strings
func filterUnique(_ origArrOfString : [String]) ->[String] {
    var filteredUnique : [String] = []
    for someString in origArrOfString {
        if(Set(someString).count == someString.count) {
            filteredUnique.append(someString)
        }
    }
    return filteredUnique
}

//test cases for filterUnique
let filteredString0 = filterUnique(stringToBeFiltered0)
let filteredString1 = filterUnique(stringToBeFiltered1)
let filteredString2 = filterUnique(stringToBeFiltered2)

print(filteredString0)
print(filteredString1)
print(filteredString2)

//params for filterDigitLength
let arrOfDigits0 = [88, 232, 4, 9721, 555]
let numOfDigits0 = 3

let arrOfDigits1 = [2, 7, 8, 9, 1012]
let numOfDigits1 = 1

let arrOfDigits2 = [32, 88, 74, 91, 300, 4050]
let numOfDigits2 = 1

let arrOfDigits3 = [5, 6, 8, 9]
let numOfDigits3 = 1

//filterDigitLength returns an array with num with specified digits
func filterDigitLength(_ origArrOfInt : [Int], _ numberOfDigits : Int) -> [Int] {
    var result : [Int] = []
    for value in origArrOfInt {
        var count = numberOfDigits
        var mutValue = value
        while mutValue >= 10 {
            mutValue /= 10
            count -= 1
        }
        count -= 1
        
        if count == 0 {
            result.append(value)
        }
    }
    return result
}
//test caes for filterDigitLength
let filteredNum0 = filterDigitLength(arrOfDigits0, numOfDigits0)
let filteredNum1 = filterDigitLength(arrOfDigits1, numOfDigits1)
let filteredNum2 = filterDigitLength(arrOfDigits2, numOfDigits2)
let filteredNum3 = filterDigitLength(arrOfDigits3, numOfDigits3)

print(filteredNum0)
print(filteredNum1)
print(filteredNum2)
print(filteredNum3)
//params for evenOddPartition
let intBeforePartition0 = [5, 8, 9, 2, 0]
let intBeforePartition1 = [1, 0, 1, 0, 1, 0]
let intBeforePartition2 = [1, 3, 5, 7, 9]
let intBeforePartition3 : [Int] = []
//function evenOddPartition split out two partitioned array with the leading one being even and the trailing one being odd
func evenOddPartition(_ origArrOfInts : [Int]) -> [[Int]] {
    var retArrOfInt : [[Int]] = []
    var oddArrOfInt : [Int] = []
    var evenArrOfInt : [Int] = []
    for value in origArrOfInts {
        if (value % 2 == 0) {
            evenArrOfInt.append(value)
        } else {oddArrOfInt.append(value)}
    }
    
    retArrOfInt.append(evenArrOfInt)
    retArrOfInt.append(oddArrOfInt)
    return retArrOfInt
}
//test cases for evenOddPartition
let partitionedArr0 = evenOddPartition(intBeforePartition0)
let partitionedArr1 = evenOddPartition(intBeforePartition1)
let partitionedArr2 = evenOddPartition(intBeforePartition2)
let partitionedArr3 = evenOddPartition(intBeforePartition3)

print(partitionedArr0)
print(partitionedArr1)
print(partitionedArr2)
print(partitionedArr3)



//params for billSplit
let spiceStatus0 = ["S", "N", "S", "S"]
let billArr0 = [13, 18, 15, 4]

// Since:
// You pay: [13, 9, 15, 4] = 41
// Friend pays: [0, 9, 0, 0] = 9

let spiceStatus1 = ["N", "S", "N"]
let billArr1 = [10, 10, 20]
// You pay for half of both "N" dishes (5 + 10) and entirely pay for the "S" dish (10).

let spiceStatus2 = ["N", "N"]
let billArr2 = [10, 10]

let spiceStatus3 = ["S", "N"]
let billArr3 = [41, 10]

//function that splits the bill between my friend and I. I eat both spicy and non spicy food
func billSplit(_ spicyOrNot : [String],_ bill : [Int]) -> [Int] {
    typealias myBill = (spice : String,price : Int)

    var splitBillList : [myBill] = []
    for (spice, price) in zip(spicyOrNot, bill) {
        splitBillList.append((spice, price))
    }
    var nonSpicyTotal = 0
    var spicyTotal = 0
    for spices in splitBillList {
        if spices.spice == "N" {
            nonSpicyTotal += spices.price
        } else if spices.spice == "S" {
            spicyTotal += spices.price
        }
    }
    nonSpicyTotal  /= 2
    spicyTotal += nonSpicyTotal
    let retArr = [spicyTotal,nonSpicyTotal]
    return retArr
}

//test cases for billSplit
let splitedBill0 = billSplit(spiceStatus0, billArr0)
let splitedBill1 = billSplit(spiceStatus1, billArr1)
let splitedBill2 = billSplit(spiceStatus2, billArr2)
let splitedBill3 = billSplit(spiceStatus3, billArr3)

print(splitedBill0)
print(splitedBill1)
print(splitedBill2)
print(splitedBill3)

//Params for isSpecialArray
let inputArr0 = [2, 7, 4, 9, 6, 1, 6, 3]
// true

let inputArr1 = [2, 7, 9, 1, 6, 1, 6, 3]
// false

let inputArr2 = [2, 7, 8, 8, 6, 1, 6, 3]
// false
//function is Special array return true if all even index is even
func isSpecialArray (inputArr: [Int]) -> Bool {
    var retBool = false;
    for (index, element) in inputArr.enumerated() {
        if (index % 2 == 0 && element % 2 == 0){
            retBool = true
        } else if (index % 2 != 0 && element % 2 != 0){
            retBool = true
        } else {
             return false
        }
    }
    return retBool;
}
//test cases for specialArray
let special0 = isSpecialArray(inputArr : inputArr0)
let special1 = isSpecialArray(inputArr : inputArr1)
let special2 = isSpecialArray(inputArr : inputArr2)

print(special0)
print(special1)
print(special2)

//Params for letterCounter
let groupOfLetters0 = [
  ["D", "E", "Y", "H", "A", "D"],
  ["C", "B", "Z", "Y", "J", "K"],
  ["D", "B", "C", "A", "M", "N"],
  ["F", "G", "G", "R", "S", "R"],
  ["V", "X", "H", "A", "S", "S"]
]

let requestLetter0 = "D"

let groupOfLetters1 = [
  ["D", "E", "Y", "H", "A", "D"],
  ["C", "B", "Z", "Y", "J", "K"],
  ["D", "B", "C", "A", "M", "N"],
  ["F", "G", "G", "R", "S", "R"],
  ["V", "X", "H", "A", "S", "S"]
]

let requestLetter1 = "H"

//function letterCounter returns a count of a letter described
func letterCounter(_ initLetter : [[String]], _ requestedLetter : String) -> Int {
    var count = 0
    let reduced = initLetter.reduce([], +)
    for element in reduced {
        if element == requestedLetter {
            count += 1
        }
    }
    return count
}
//test cases for letterCounter
let countOfLetter0 = letterCounter(groupOfLetters0, requestLetter0)
let countOfLetter1 = letterCounter(groupOfLetters1, requestLetter1)

print (countOfLetter0)
print (countOfLetter1)



